# 🌱 Plant Disease Detector

AI-powered web application for identifying plant diseases and pests through image analysis or symptom questionnaire, with an interactive chatbot for treatment advice.

## ✨ Features

- 📷 **Camera Capture** - Take photos directly from your device
- 📁 **Image Upload** - Upload existing plant photos
- 📝 **Symptom Questionnaire** - Describe symptoms when you can't take photos
- 🤖 **AI Analysis** - Powered by Google Gemini Vision AI
- 💊 **Treatment Solutions** - Detailed recommendations for each disease
- 💬 **Interactive Chat** - AI assistant answers your questions
- 📱 **Responsive Design** - Works on desktop and mobile

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Get Google Gemini API Key
1. Go to [Google AI Studio](https://aistudio.google.com/app/apikey)
2. Create a free API key
3. Copy your API key

### 3. Configure Environment
```bash
cp .env.example .env
```

Edit `.env` and add your Gemini API key:
```
GEMINI_API_KEY=your_api_key_here
```

### 4. Start the Server
```bash
npm start
```

### 5. Open in Browser
Navigate to `http://localhost:3000`

## 📖 How to Use

### Option 1: Image Analysis
1. Click **"Use Camera"** to take a photo or **"Upload Image"** to select one
2. Click **"Analyze Plant"**
3. Get AI-powered diagnosis with treatment recommendations
4. Chat with the AI assistant for more details

### Option 2: Symptom Questionnaire
Perfect when you can't take photos!

1. Click **"Describe Symptoms"**
2. Answer 5 simple questions:
   - What type of plant?
   - What do you see on the leaves?
   - What color are the leaves?
   - Any other symptoms?
   - What are the growing conditions?
3. Get instant diagnosis and treatment plan

## 🔍 What It Detects

The AI can identify various plant diseases including:
- Fungal diseases (Late Blight, Powdery Mildew, Early Blight, etc.)
- Bacterial infections (Bacterial Spot, etc.)
- Pest infestations (Aphids, Hornworms, Spider Mites, etc.)
- Nutrient deficiencies
- Environmental stress

## 💡 Features Breakdown

### AI Image Analysis
- Uses Google Gemini Vision AI
- Analyzes leaf color, texture, spots, and damage
- Identifies specific diseases and pests
- Provides confidence level for diagnosis

### Symptom Questionnaire
- Rule-based diagnosis system
- Works offline (no API needed)
- Covers 12+ common plant diseases
- Great for farmers with limited connectivity

### Interactive Chat
- Powered by Google Gemini AI
- Ask about treatment details
- Get product recommendations
- Learn prevention methods
- Organic alternatives

## 🛠️ Tech Stack

- **Frontend**: HTML, CSS, JavaScript
- **Backend**: Node.js, Express
- **AI**: Google Gemini API (Vision + Text)
- **Image Processing**: Multer

## 📦 Project Structure

```
plant-disease-detector/
├── index.html          # Main web page
├── style.css           # Styling
├── script.js           # Frontend logic
├── server.js           # Backend API
├── package.json        # Dependencies
├── .env.example        # Environment template
└── uploads/            # Temporary image storage
```

## 🌐 Browser Support

- ✅ Chrome/Edge - Full support
- ✅ Firefox - Full support  
- ✅ Safari - Full support (iOS 11+)
- ⚠️ Camera requires HTTPS in production

## 📝 License

MIT

## 🤝 Contributing

Contributions welcome! Feel free to submit issues and pull requests.

---

Made with ❤️ for farmers and plant enthusiasts
