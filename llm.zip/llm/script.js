// DOM Elements
const cameraBtn = document.getElementById('cameraBtn');
const fileInput = document.getElementById('fileInput');
const cameraContainer = document.getElementById('cameraContainer');
const video = document.getElementById('video');
const captureBtn = document.getElementById('captureBtn');
const closeCameraBtn = document.getElementById('closeCameraBtn');
const imagePreview = document.getElementById('imagePreview');
const previewImg = document.getElementById('previewImg');
const canvas = document.getElementById('canvas');
const analyzeBtn = document.getElementById('analyzeBtn');
const resultsSection = document.getElementById('resultsSection');
const results = document.getElementById('results');
const chatSection = document.getElementById('chatSection');
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const sendBtn = document.getElementById('sendBtn');

let stream = null;
let currentImage = null;
let analysisData = null;

// Questionnaire state
let currentQuestionIndex = 0;
let questionnaireAnswers = {};

// Questionnaire questions
const questions = [
    {
        id: 'plantType',
        question: 'What type of plant are you growing?',
        options: [
            { value: 'tomato', label: 'Tomato', icon: '🍅' },
            { value: 'potato', label: 'Potato', icon: '🥔' },
            { value: 'pepper', label: 'Pepper', icon: '🌶️' },
            { value: 'cucumber', label: 'Cucumber', icon: '🥒' },
            { value: 'leafy', label: 'Leafy Greens (Lettuce, Spinach)', icon: '🥬' },
            { value: 'other', label: 'Other Vegetable/Fruit', icon: '🌱' }
        ]
    },
    {
        id: 'leafSymptoms',
        question: 'What do you see on the leaves?',
        options: [
            { value: 'spots_brown', label: 'Brown or black spots', icon: '🟤' },
            { value: 'spots_yellow', label: 'Yellow spots or patches', icon: '🟡' },
            { value: 'white_powder', label: 'White powdery coating', icon: '⚪' },
            { value: 'holes', label: 'Holes or eaten edges', icon: '🕳️' },
            { value: 'wilting', label: 'Wilting or drooping', icon: '🥀' },
            { value: 'curling', label: 'Curling or distorted leaves', icon: '🌀' },
            { value: 'healthy', label: 'Leaves look healthy', icon: '✅' }
        ]
    },
    {
        id: 'leafColor',
        question: 'What is the overall color of the leaves?',
        options: [
            { value: 'green', label: 'Healthy green', icon: '🟢' },
            { value: 'yellow', label: 'Yellowing (chlorosis)', icon: '🟡' },
            { value: 'brown', label: 'Brown or dying', icon: '🟤' },
            { value: 'pale', label: 'Pale or light green', icon: '⚪' },
            { value: 'dark', label: 'Dark green or purple tint', icon: '🟣' }
        ]
    },
    {
        id: 'otherSymptoms',
        question: 'Are there any other symptoms?',
        options: [
            { value: 'mold', label: 'Fuzzy mold or fungus growth', icon: '🍄' },
            { value: 'insects', label: 'Visible insects or bugs', icon: '🐛' },
            { value: 'sticky', label: 'Sticky residue on leaves', icon: '💧' },
            { value: 'stunted', label: 'Stunted or slow growth', icon: '📉' },
            { value: 'fruit_damage', label: 'Damage on fruits/vegetables', icon: '🍎' },
            { value: 'stem_damage', label: 'Stem discoloration or damage', icon: '🌿' },
            { value: 'none', label: 'None of the above', icon: '❌' }
        ]
    },
    {
        id: 'environment',
        question: 'What are the growing conditions?',
        options: [
            { value: 'wet', label: 'Very wet, lots of rain', icon: '🌧️' },
            { value: 'humid', label: 'Humid and warm', icon: '💨' },
            { value: 'dry', label: 'Dry, not much water', icon: '☀️' },
            { value: 'crowded', label: 'Plants are crowded together', icon: '🌳' },
            { value: 'shaded', label: 'Mostly shaded area', icon: '🌑' },
            { value: 'normal', label: 'Normal conditions', icon: '🌤️' }
        ]
    }
];

// Questionnaire functionality
const questionnaireBtn = document.getElementById('questionnaireBtn');
const questionnaireContainer = document.getElementById('questionnaireContainer');
const questionnaireContent = document.getElementById('questionnaireContent');
const progressText = document.getElementById('progressText');
const progressFill = document.getElementById('progressFill');

questionnaireBtn.addEventListener('click', () => {
    startQuestionnaire();
});

function startQuestionnaire() {
    currentQuestionIndex = 0;
    questionnaireAnswers = {};
    questionnaireContainer.classList.remove('hidden');
    imagePreview.classList.add('hidden');
    cameraContainer.classList.add('hidden');
    resultsSection.classList.add('hidden');
    chatSection.classList.add('hidden');
    showQuestion();
}

function showQuestion() {
    const question = questions[currentQuestionIndex];
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;
    
    progressText.textContent = `Question ${currentQuestionIndex + 1} of ${questions.length}`;
    progressFill.style.width = `${progress}%`;
    
    let optionsHTML = question.options.map(option => `
        <button class="option-btn" data-value="${option.value}">
            <span class="option-icon">${option.icon}</span>
            <span>${option.label}</span>
        </button>
    `).join('');
    
    questionnaireContent.innerHTML = `
        <h3 class="question-title">${question.question}</h3>
        <div class="options-grid">
            ${optionsHTML}
        </div>
        <div class="questionnaire-nav">
            ${currentQuestionIndex > 0 ? '<button class="btn btn-secondary" id="prevBtn">← Previous</button>' : '<div></div>'}
            <button class="btn btn-danger" id="cancelBtn">Cancel</button>
        </div>
    `;
    
    // Add event listeners to options
    document.querySelectorAll('.option-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            selectOption(e.currentTarget);
        });
    });
    
    // Previous button
    const prevBtn = document.getElementById('prevBtn');
    if (prevBtn) {
        prevBtn.addEventListener('click', () => {
            currentQuestionIndex--;
            showQuestion();
        });
    }
    
    // Cancel button
    document.getElementById('cancelBtn').addEventListener('click', () => {
        questionnaireContainer.classList.add('hidden');
    });
}

function selectOption(button) {
    const question = questions[currentQuestionIndex];
    const value = button.dataset.value;
    
    // Store answer
    questionnaireAnswers[question.id] = value;
    
    // Visual feedback
    document.querySelectorAll('.option-btn').forEach(btn => {
        btn.classList.remove('selected');
    });
    button.classList.add('selected');
    
    // Move to next question after a short delay
    setTimeout(() => {
        if (currentQuestionIndex < questions.length - 1) {
            currentQuestionIndex++;
            showQuestion();
        } else {
            // All questions answered, analyze
            analyzeQuestionnaire();
        }
    }, 300);
}

async function analyzeQuestionnaire() {
    questionnaireContainer.classList.add('hidden');
    resultsSection.classList.remove('hidden');
    results.innerHTML = '<div class="loading">🔍 Analyzing your symptoms...</div>';
    
    try {
        const response = await fetch('http://localhost:3000/api/questionnaire', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ answers: questionnaireAnswers })
        });
        
        if (!response.ok) {
            throw new Error('Analysis failed');
        }
        
        analysisData = await response.json();
        displayResults(analysisData);
        chatSection.classList.remove('hidden');
        initializeChat();
        
    } catch (error) {
        console.error('Questionnaire analysis error:', error);
        // Fallback to local analysis
        analysisData = analyzeQuestionnaireLocally(questionnaireAnswers);
        displayResults(analysisData);
        chatSection.classList.remove('hidden');
        initializeChat();
    }
}

function analyzeQuestionnaireLocally(answers) {
    // Simple rule-based diagnosis
    const { plantType, leafSymptoms, leafColor, otherSymptoms, environment } = answers;
    
    // Late Blight detection
    if ((leafSymptoms === 'spots_brown' || leafSymptoms === 'wilting') && 
        (environment === 'wet' || environment === 'humid') &&
        (otherSymptoms === 'mold' || otherSymptoms === 'fruit_damage')) {
        return {
            disease: 'Late Blight',
            pest: 'Phytophthora infestans (fungus-like organism)',
            confidence: 85,
            symptoms: [
                'Dark brown to black lesions on leaves',
                'White fuzzy growth on leaf undersides',
                'Brown spots on stems',
                'Fruit rot with firm, brown lesions'
            ],
            causes: [
                'Cool, wet weather conditions',
                'High humidity (above 90%)',
                'Poor air circulation'
            ],
            solutions: [
                'Remove and destroy infected plant parts immediately',
                'Apply copper-based fungicide every 7-10 days',
                'Use fungicides containing chlorothalonil or mancozeb',
                'Improve air circulation by proper spacing',
                'Water plants at base, avoid wetting foliage'
            ],
            prevention: [
                'Choose disease-resistant varieties',
                'Ensure proper plant spacing (24-36 inches)',
                'Water in morning to allow foliage to dry',
                'Remove plant debris at end of season'
            ]
        };
    }
    
    // Powdery Mildew detection
    if (leafSymptoms === 'white_powder' || 
        (otherSymptoms === 'mold' && (environment === 'humid' || environment === 'crowded'))) {
        return {
            disease: 'Powdery Mildew',
            pest: 'Various fungal species',
            confidence: 90,
            symptoms: [
                'White powdery spots on leaves',
                'Yellowing of leaves',
                'Leaf curling and distortion',
                'Stunted growth'
            ],
            causes: [
                'High humidity with dry conditions',
                'Poor air circulation',
                'Overcrowding of plants'
            ],
            solutions: [
                'Spray with neem oil solution',
                'Apply sulfur-based fungicide',
                'Use baking soda spray (1 tbsp per gallon)',
                'Remove heavily infected leaves',
                'Increase air circulation'
            ],
            prevention: [
                'Space plants properly',
                'Prune to improve air flow',
                'Avoid overhead watering',
                'Plant in sunny locations'
            ]
        };
    }
    
    // Pest infestation
    if (leafSymptoms === 'holes' || otherSymptoms === 'insects' || otherSymptoms === 'sticky') {
        return {
            disease: 'Pest Infestation (Aphids/Caterpillars)',
            pest: 'Various insects (aphids, caterpillars, beetles)',
            confidence: 88,
            symptoms: [
                'Holes in leaves',
                'Visible insects on plant',
                'Sticky honeydew residue',
                'Curled or distorted leaves'
            ],
            causes: [
                'Lack of natural predators',
                'Warm weather conditions',
                'Stressed plants'
            ],
            solutions: [
                'Spray with insecticidal soap',
                'Use neem oil spray',
                'Hand-pick larger pests',
                'Apply diatomaceous earth around plants',
                'Introduce beneficial insects (ladybugs)'
            ],
            prevention: [
                'Regular inspection of plants',
                'Encourage beneficial insects',
                'Use row covers',
                'Keep plants healthy and well-watered'
            ]
        };
    }
    
    // Nutrient deficiency
    if (leafColor === 'yellow' || leafColor === 'pale' || otherSymptoms === 'stunted') {
        return {
            disease: 'Nutrient Deficiency',
            pest: 'Not a disease - nutritional issue',
            confidence: 80,
            symptoms: [
                'Yellowing leaves (chlorosis)',
                'Stunted growth',
                'Pale or light-colored foliage',
                'Poor fruit development'
            ],
            causes: [
                'Nitrogen deficiency',
                'Iron deficiency (alkaline soil)',
                'Poor soil quality',
                'Overwatering or underwatering'
            ],
            solutions: [
                'Apply balanced fertilizer (10-10-10)',
                'Add compost or organic matter',
                'Use iron chelate for iron deficiency',
                'Test soil pH and adjust if needed',
                'Ensure proper watering schedule'
            ],
            prevention: [
                'Regular fertilization schedule',
                'Maintain proper soil pH (6.0-6.8)',
                'Add compost annually',
                'Mulch to retain moisture'
            ]
        };
    }
    
    // Fungal disease (general)
    if (leafSymptoms === 'spots_yellow' || leafSymptoms === 'curling' || otherSymptoms === 'stem_damage') {
        return {
            disease: 'Fungal Leaf Spot',
            pest: 'Various fungal pathogens',
            confidence: 82,
            symptoms: [
                'Yellow or brown spots on leaves',
                'Spots may have dark borders',
                'Leaf drop',
                'Reduced plant vigor'
            ],
            causes: [
                'Wet foliage',
                'High humidity',
                'Poor air circulation',
                'Overhead watering'
            ],
            solutions: [
                'Remove infected leaves',
                'Apply copper fungicide',
                'Use organic fungicide (neem oil)',
                'Improve air circulation',
                'Water at soil level only'
            ],
            prevention: [
                'Water in morning',
                'Space plants properly',
                'Remove plant debris',
                'Rotate crops annually'
            ]
        };
    }
    
    // Default - healthy or minor issues
    return {
        disease: 'Minor Issues or Healthy Plant',
        pest: 'No major disease detected',
        confidence: 75,
        symptoms: [
            'Based on your description, no major disease detected',
            'Some minor stress symptoms may be present'
        ],
        causes: [
            'Environmental stress',
            'Minor nutrient imbalance',
            'Normal plant variation'
        ],
        solutions: [
            'Continue regular care and monitoring',
            'Ensure consistent watering',
            'Apply balanced fertilizer if needed',
            'Monitor for any changes',
            'Maintain good garden hygiene'
        ],
        prevention: [
            'Regular inspection',
            'Proper watering schedule',
            'Good air circulation',
            'Healthy soil maintenance'
        ]
    };
}

// Camera functionality
cameraBtn.addEventListener('click', async () => {
    try {
        stream = await navigator.mediaDevices.getUserMedia({ 
            video: { facingMode: 'environment' } 
        });
        video.srcObject = stream;
        cameraContainer.classList.remove('hidden');
        imagePreview.classList.add('hidden');
    } catch (error) {
        alert('Camera access denied or not available');
        console.error(error);
    }
});

closeCameraBtn.addEventListener('click', () => {
    stopCamera();
});

captureBtn.addEventListener('click', () => {
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    canvas.getContext('2d').drawImage(video, 0, 0);
    
    currentImage = canvas.toDataURL('image/jpeg');
    previewImg.src = currentImage;
    
    stopCamera();
    imagePreview.classList.remove('hidden');
});

function stopCamera() {
    if (stream) {
        stream.getTracks().forEach(track => track.stop());
        stream = null;
    }
    cameraContainer.classList.add('hidden');
}

// File upload
fileInput.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
            currentImage = event.target.result;
            previewImg.src = currentImage;
            imagePreview.classList.remove('hidden');
            cameraContainer.classList.add('hidden');
        };
        reader.readAsDataURL(file);
    }
});

// Analyze image
analyzeBtn.addEventListener('click', async () => {
    if (!currentImage) return;
    
    results.innerHTML = '<div class="loading">🔍 Analyzing plant image...</div>';
    resultsSection.classList.remove('hidden');
    
    await analyzePlantImage();
});

async function analyzePlantImage() {
    try {
        // Convert base64 to blob
        const blob = await fetch(currentImage).then(r => r.blob());
        
        // Create form data
        const formData = new FormData();
        formData.append('image', blob, 'plant.jpg');
        
        // Call backend API
        const response = await fetch('http://localhost:3000/api/analyze', {
            method: 'POST',
            body: formData
        });
        
        if (!response.ok) {
            throw new Error('Analysis failed');
        }
        
        analysisData = await response.json();
        displayResults(analysisData);
        chatSection.classList.remove('hidden');
        initializeChat();
        
    } catch (error) {
        console.error('Analysis error:', error);
        results.innerHTML = `
            <div class="disease-card">
                <h3>⚠️ Analysis Error</h3>
                <p>Unable to analyze the image. Please make sure the server is running.</p>
                <p style="margin-top: 10px; color: #666;">Run: <code>npm install && npm start</code></p>
            </div>
        `;
    }
}

function displayResults(data) {
    results.innerHTML = `
        <div class="disease-card">
            <h3>🦠 Detected: ${data.disease}</h3>
            <p class="confidence">Confidence: ${data.confidence}%</p>
            
            <div class="info-section">
                <h4>🐛 Caused by:</h4>
                <p>${data.pest}</p>
            </div>
            
            <div class="info-section">
                <h4>📋 Symptoms:</h4>
                <ul>
                    ${data.symptoms.map(s => `<li>${s}</li>`).join('')}
                </ul>
            </div>
            
            <div class="info-section">
                <h4>🔍 Common Causes:</h4>
                <ul>
                    ${data.causes.map(c => `<li>${c}</li>`).join('')}
                </ul>
            </div>
            
            <div class="info-section">
                <h4>💊 Treatment Solutions:</h4>
                <ul>
                    ${data.solutions.map(s => `<li>${s}</li>`).join('')}
                </ul>
            </div>
            
            <div class="info-section">
                <h4>🛡️ Prevention Tips:</h4>
                <ul>
                    ${data.prevention.map(p => `<li>${p}</li>`).join('')}
                </ul>
            </div>
        </div>
    `;
}

// Chat functionality
function initializeChat() {
    chatMessages.innerHTML = '';
    addBotMessage("Hi! I'm here to help with your plant disease questions. You can ask me about:");
    addBotMessage("• Treatment details\n• Prevention methods\n• Product recommendations\n• Application frequency\n• Organic alternatives");
}

sendBtn.addEventListener('click', sendMessage);
chatInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') sendMessage();
});

async function sendMessage() {
    const message = chatInput.value.trim();
    if (!message) return;
    
    addUserMessage(message);
    chatInput.value = '';
    
    // Show typing indicator
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot';
    typingDiv.innerHTML = '💭 Thinking...';
    typingDiv.id = 'typing-indicator';
    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
    
    try {
        // Call backend chat API
        const response = await fetch('http://localhost:3000/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: message,
                context: analysisData
            })
        });
        
        const data = await response.json();
        
        // Remove typing indicator
        document.getElementById('typing-indicator')?.remove();
        
        addBotMessage(data.response);
        
    } catch (error) {
        console.error('Chat error:', error);
        document.getElementById('typing-indicator')?.remove();
        
        // Fallback to local response
        const response = generateBotResponse(message);
        addBotMessage(response);
    }
}

function addUserMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message user';
    messageDiv.textContent = text;
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function addBotMessage(text) {
    const messageDiv = document.createElement('div');
    messageDiv.className = 'message bot';
    messageDiv.innerHTML = text.replace(/\n/g, '<br>');
    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function generateBotResponse(question) {
    const q = question.toLowerCase();
    
    if (!analysisData) {
        return "Please analyze a plant image first to get specific recommendations.";
    }
    
    // Simple keyword-based responses - Replace with actual AI/NLP in production
    if (q.includes('how often') || q.includes('frequency') || q.includes('when')) {
        return `<strong>Application Frequency:</strong><br>
        For ${analysisData.disease}, apply fungicide every 7-10 days. 
        Start treatment as soon as symptoms appear. 
        Continue for 2-3 weeks after symptoms disappear. 
        Reapply after heavy rain.`;
    }
    
    if (q.includes('organic') || q.includes('natural')) {
        return `<strong>Organic Treatment Options:</strong><br>
        • Neem oil spray (every 7 days)<br>
        • Baking soda solution (1 tbsp per gallon)<br>
        • Copper soap fungicide<br>
        • Bacillus subtilis biological fungicide<br>
        • Milk spray (1:9 milk to water ratio)`;
    }
    
    if (q.includes('product') || q.includes('recommend') || q.includes('buy')) {
        return `<strong>Recommended Products:</strong><br>
        • Daconil (chlorothalonil) - broad spectrum<br>
        • Bonide Copper Fungicide - organic option<br>
        • Serenade Garden - biological control<br>
        • Mancozeb fungicide - preventive<br>
        Always follow label instructions!`;
    }
    
    if (q.includes('spread') || q.includes('contagious')) {
        return `<strong>Disease Spread:</strong><br>
        ${analysisData.disease} spreads through water splash, wind, and contaminated tools. 
        Isolate infected plants, disinfect tools with 10% bleach solution, 
        and avoid working with plants when wet.`;
    }
    
    if (q.includes('save') || q.includes('too late')) {
        return `<strong>Can it be saved?</strong><br>
        If less than 50% of the plant is affected, treatment can be effective. 
        Remove all infected parts, apply fungicide, and monitor closely. 
        If more than 50% is damaged, it's better to remove the plant to prevent spread.`;
    }
    
    if (q.includes('prevent') || q.includes('stop')) {
        return `<strong>Prevention Tips:</strong><br>
        ${analysisData.prevention.slice(0, 3).map(p => `• ${p}`).join('<br>')}`;
    }
    
    // Default response
    return `Based on the detected ${analysisData.disease}, I recommend following the treatment solutions shown above. 
    The key is early detection and consistent treatment. 
    Would you like specific information about application frequency, organic options, or product recommendations?`;
}
