const express = require('express');
const cors = require('cors');
const multer = require('multer');
const axios = require('axios');
const FormData = require('form-data');
const fs = require('fs');
const path = require('path');
const { GoogleGenerativeAI } = require('@google/generative-ai');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.static('public'));

// File upload configuration
const upload = multer({
    dest: 'uploads/',
    limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// Serve static files
app.use(express.static('.'));

// Health check
app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'Server is running' });
});

// Analyze plant image endpoint
app.post('/api/analyze', upload.single('image'), async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No image provided' });
        }

        const geminiApiKey = process.env.GEMINI_API_KEY;
        
        if (!geminiApiKey) {
            console.log('No Gemini API key found, using mock data');
            fs.unlinkSync(req.file.path);
            return res.json(getMockAnalysis());
        }

        // Read the uploaded file
        const imageBuffer = fs.readFileSync(req.file.path);
        const base64Image = imageBuffer.toString('base64');

        // Use Gemini API with vision
        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro-vision:generateContent?key=${geminiApiKey}`;

        const prompt = `You are an expert plant pathologist. Carefully analyze this plant image and provide a detailed, accurate diagnosis.

Look for:
- Leaf discoloration (yellow, brown, black spots)
- Leaf texture (powdery coating, fuzzy growth, holes)
- Plant structure (wilting, curling, stunted growth)
- Visible pests or insects
- Fruit/vegetable damage

Provide your diagnosis in this EXACT JSON format (no markdown, no code blocks):
{
  "disease": "Specific disease name or 'Healthy Plant'",
  "pest": "Causative agent (specific fungus, bacteria, pest name)",
  "confidence": 85,
  "symptoms": ["specific symptom 1", "specific symptom 2", "specific symptom 3"],
  "causes": ["specific cause 1", "specific cause 2"],
  "solutions": ["detailed solution 1", "detailed solution 2", "detailed solution 3"],
  "prevention": ["prevention tip 1", "prevention tip 2", "prevention tip 3"]
}

Be specific and accurate based on what you see in the image.`;

        const requestBody = {
            contents: [{
                parts: [
                    { text: prompt },
                    {
                        inline_data: {
                            mime_type: req.file.mimetype,
                            data: base64Image
                        }
                    }
                ]
            }],
            generationConfig: {
                temperature: 0.4,
                topK: 32,
                topP: 1,
                maxOutputTokens: 2048
            }
        };

        console.log('Calling Gemini API for image analysis...');
        const response = await axios.post(apiUrl, requestBody, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        // Clean up uploaded file
        fs.unlinkSync(req.file.path);

        const text = response.data.candidates[0].content.parts[0].text;
        console.log('Gemini response received:', text.substring(0, 200));
        
        // Parse JSON from response
        let analysisData;
        try {
            // Remove markdown code blocks if present
            const cleanText = text.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
            analysisData = JSON.parse(cleanText);
            console.log('✓ Gemini analysis successful:', analysisData.disease);
        } catch (parseError) {
            console.error('JSON parse error:', parseError);
            console.log('Raw response:', text);
            // Try to extract JSON from text
            const jsonMatch = text.match(/\{[\s\S]*\}/);
            if (jsonMatch) {
                try {
                    analysisData = JSON.parse(jsonMatch[0]);
                    console.log('✓ Extracted JSON successfully');
                } catch (e) {
                    console.log('Failed to extract JSON, using mock data');
                    return res.json(getMockAnalysis());
                }
            } else {
                return res.json(getMockAnalysis());
            }
        }

        res.json(analysisData);

    } catch (error) {
        console.error('Analysis error:', error.message);
        console.error('Full error:', error);
        
        // Clean up file if it exists
        if (req.file && fs.existsSync(req.file.path)) {
            fs.unlinkSync(req.file.path);
        }

        // Return mock data on error
        console.log('Falling back to mock data');
        res.json(getMockAnalysis());
    }
});

// Questionnaire endpoint
app.post('/api/questionnaire', async (req, res) => {
    try {
        const { answers } = req.body;
        
        if (!answers) {
            return res.status(400).json({ error: 'No answers provided' });
        }

        // Analyze questionnaire answers
        const diagnosis = analyzeQuestionnaireAnswers(answers);
        res.json(diagnosis);

    } catch (error) {
        console.error('Questionnaire error:', error.message);
        res.status(500).json({ error: 'Analysis failed' });
    }
});

// Analyze questionnaire answers
function analyzeQuestionnaireAnswers(answers) {
    const { plantType, leafSymptoms, leafColor, otherSymptoms, environment } = answers;
    
    // Late Blight detection
    if ((leafSymptoms === 'spots_brown' || leafSymptoms === 'wilting') && 
        (environment === 'wet' || environment === 'humid') &&
        (otherSymptoms === 'mold' || otherSymptoms === 'fruit_damage')) {
        return {
            disease: 'Late Blight',
            pest: 'Phytophthora infestans (fungus-like organism)',
            confidence: 85,
            symptoms: [
                'Dark brown to black lesions on leaves',
                'White fuzzy growth on leaf undersides',
                'Brown spots on stems',
                'Fruit rot with firm, brown lesions'
            ],
            causes: [
                'Cool, wet weather conditions',
                'High humidity (above 90%)',
                'Poor air circulation'
            ],
            solutions: [
                'Remove and destroy infected plant parts immediately',
                'Apply copper-based fungicide every 7-10 days',
                'Use fungicides containing chlorothalonil or mancozeb',
                'Improve air circulation by proper spacing',
                'Water plants at base, avoid wetting foliage'
            ],
            prevention: [
                'Choose disease-resistant varieties',
                'Ensure proper plant spacing (24-36 inches)',
                'Water in morning to allow foliage to dry',
                'Remove plant debris at end of season'
            ]
        };
    }
    
    // Powdery Mildew detection
    if (leafSymptoms === 'white_powder' || 
        (otherSymptoms === 'mold' && (environment === 'humid' || environment === 'crowded'))) {
        return {
            disease: 'Powdery Mildew',
            pest: 'Various fungal species',
            confidence: 90,
            symptoms: [
                'White powdery spots on leaves',
                'Yellowing of leaves',
                'Leaf curling and distortion',
                'Stunted growth'
            ],
            causes: [
                'High humidity with dry conditions',
                'Poor air circulation',
                'Overcrowding of plants'
            ],
            solutions: [
                'Spray with neem oil solution',
                'Apply sulfur-based fungicide',
                'Use baking soda spray (1 tbsp per gallon)',
                'Remove heavily infected leaves',
                'Increase air circulation'
            ],
            prevention: [
                'Space plants properly',
                'Prune to improve air flow',
                'Avoid overhead watering',
                'Plant in sunny locations'
            ]
        };
    }
    
    // Pest infestation
    if (leafSymptoms === 'holes' || otherSymptoms === 'insects' || otherSymptoms === 'sticky') {
        return {
            disease: 'Pest Infestation (Aphids/Caterpillars)',
            pest: 'Various insects (aphids, caterpillars, beetles)',
            confidence: 88,
            symptoms: [
                'Holes in leaves',
                'Visible insects on plant',
                'Sticky honeydew residue',
                'Curled or distorted leaves'
            ],
            causes: [
                'Lack of natural predators',
                'Warm weather conditions',
                'Stressed plants'
            ],
            solutions: [
                'Spray with insecticidal soap',
                'Use neem oil spray',
                'Hand-pick larger pests',
                'Apply diatomaceous earth around plants',
                'Introduce beneficial insects (ladybugs)'
            ],
            prevention: [
                'Regular inspection of plants',
                'Encourage beneficial insects',
                'Use row covers',
                'Keep plants healthy and well-watered'
            ]
        };
    }
    
    // Nutrient deficiency
    if (leafColor === 'yellow' || leafColor === 'pale' || otherSymptoms === 'stunted') {
        return {
            disease: 'Nutrient Deficiency',
            pest: 'Not a disease - nutritional issue',
            confidence: 80,
            symptoms: [
                'Yellowing leaves (chlorosis)',
                'Stunted growth',
                'Pale or light-colored foliage',
                'Poor fruit development'
            ],
            causes: [
                'Nitrogen deficiency',
                'Iron deficiency (alkaline soil)',
                'Poor soil quality',
                'Overwatering or underwatering'
            ],
            solutions: [
                'Apply balanced fertilizer (10-10-10)',
                'Add compost or organic matter',
                'Use iron chelate for iron deficiency',
                'Test soil pH and adjust if needed',
                'Ensure proper watering schedule'
            ],
            prevention: [
                'Regular fertilization schedule',
                'Maintain proper soil pH (6.0-6.8)',
                'Add compost annually',
                'Mulch to retain moisture'
            ]
        };
    }
    
    // Fungal disease (general)
    if (leafSymptoms === 'spots_yellow' || leafSymptoms === 'curling' || otherSymptoms === 'stem_damage') {
        return {
            disease: 'Fungal Leaf Spot',
            pest: 'Various fungal pathogens',
            confidence: 82,
            symptoms: [
                'Yellow or brown spots on leaves',
                'Spots may have dark borders',
                'Leaf drop',
                'Reduced plant vigor'
            ],
            causes: [
                'Wet foliage',
                'High humidity',
                'Poor air circulation',
                'Overhead watering'
            ],
            solutions: [
                'Remove infected leaves',
                'Apply copper fungicide',
                'Use organic fungicide (neem oil)',
                'Improve air circulation',
                'Water at soil level only'
            ],
            prevention: [
                'Water in morning',
                'Space plants properly',
                'Remove plant debris',
                'Rotate crops annually'
            ]
        };
    }
    
    // Default - healthy or minor issues
    return {
        disease: 'Minor Issues or Healthy Plant',
        pest: 'No major disease detected',
        confidence: 75,
        symptoms: [
            'Based on your description, no major disease detected',
            'Some minor stress symptoms may be present'
        ],
        causes: [
            'Environmental stress',
            'Minor nutrient imbalance',
            'Normal plant variation'
        ],
        solutions: [
            'Continue regular care and monitoring',
            'Ensure consistent watering',
            'Apply balanced fertilizer if needed',
            'Monitor for any changes',
            'Maintain good garden hygiene'
        ],
        prevention: [
            'Regular inspection',
            'Proper watering schedule',
            'Good air circulation',
            'Healthy soil maintenance'
        ]
    };
}

// Chat endpoint
app.post('/api/chat', async (req, res) => {
    try {
        const { message, context } = req.body;

        // Use Gemini for AI responses
        const response = await getAIResponse(message, context);
        res.json({ response });

    } catch (error) {
        console.error('Chat error:', error.message);
        res.json({ 
            response: 'I apologize, but I encountered an error. Please try rephrasing your question.' 
        });
    }
});

// Process Plant.id API response
function processPlantIdResponse(data) {
    const healthAssessment = data.health_assessment;
    
    if (!healthAssessment || !healthAssessment.diseases || healthAssessment.diseases.length === 0) {
        return {
            disease: 'Healthy Plant',
            pest: 'No disease detected',
            confidence: 95,
            symptoms: ['Plant appears healthy'],
            causes: ['N/A'],
            solutions: ['Continue regular care and monitoring'],
            prevention: ['Maintain good watering practices', 'Ensure adequate sunlight', 'Monitor regularly']
        };
    }

    const topDisease = healthAssessment.diseases[0];
    
    return {
        disease: topDisease.name || 'Unknown Disease',
        pest: topDisease.disease_details?.cause || 'Unknown cause',
        confidence: Math.round((topDisease.probability || 0) * 100),
        symptoms: topDisease.disease_details?.description?.split('.').filter(s => s.trim()) || ['Symptoms not available'],
        causes: [topDisease.disease_details?.cause || 'Cause not specified'],
        solutions: topDisease.disease_details?.treatment?.chemical || topDisease.disease_details?.treatment?.biological || ['Consult a plant specialist'],
        prevention: topDisease.disease_details?.treatment?.prevention || ['Regular monitoring', 'Proper plant care']
    };
}

// Mock analysis data with comprehensive disease database
function getMockAnalysis() {
    const diseases = [
        {
            disease: 'Tomato Late Blight',
            pest: 'Phytophthora infestans (fungus-like organism)',
            confidence: 87,
            symptoms: [
                'Dark brown to black lesions on leaves',
                'White fuzzy growth on leaf undersides',
                'Brown spots on stems',
                'Fruit rot with firm, brown lesions'
            ],
            causes: [
                'Cool, wet weather conditions',
                'High humidity (above 90%)',
                'Poor air circulation'
            ],
            solutions: [
                'Remove and destroy infected plant parts immediately',
                'Apply copper-based fungicide every 7-10 days',
                'Use fungicides containing chlorothalonil or mancozeb',
                'Improve air circulation by proper spacing',
                'Water plants at base, avoid wetting foliage'
            ],
            prevention: [
                'Choose disease-resistant varieties',
                'Ensure proper plant spacing (24-36 inches)',
                'Water in morning to allow foliage to dry',
                'Remove plant debris at end of season'
            ]
        },
        {
            disease: 'Powdery Mildew',
            pest: 'Various fungal species',
            confidence: 92,
            symptoms: [
                'White powdery spots on leaves',
                'Yellowing of leaves',
                'Leaf curling and distortion',
                'Stunted growth'
            ],
            causes: [
                'High humidity with dry conditions',
                'Poor air circulation',
                'Overcrowding of plants'
            ],
            solutions: [
                'Spray with neem oil solution',
                'Apply sulfur-based fungicide',
                'Use baking soda spray (1 tbsp per gallon)',
                'Remove heavily infected leaves',
                'Increase air circulation'
            ],
            prevention: [
                'Space plants properly',
                'Prune to improve air flow',
                'Avoid overhead watering',
                'Plant in sunny locations'
            ]
        },
        {
            disease: 'Early Blight',
            pest: 'Alternaria solani (fungus)',
            confidence: 85,
            symptoms: [
                'Dark brown spots with concentric rings on older leaves',
                'Yellow halo around spots',
                'Leaf drop starting from bottom',
                'Stem lesions with dark rings'
            ],
            causes: [
                'Warm, humid weather',
                'Overhead watering',
                'Infected plant debris',
                'Stressed plants'
            ],
            solutions: [
                'Remove infected lower leaves',
                'Apply chlorothalonil fungicide weekly',
                'Use copper-based organic fungicides',
                'Mulch to prevent soil splash',
                'Stake plants for better air flow'
            ],
            prevention: [
                'Rotate crops every 3 years',
                'Water at soil level',
                'Remove plant debris in fall',
                'Use disease-resistant varieties'
            ]
        },
        {
            disease: 'Septoria Leaf Spot',
            pest: 'Septoria lycopersici (fungus)',
            confidence: 88,
            symptoms: [
                'Small circular spots with gray centers',
                'Dark brown margins on spots',
                'Black dots in center of spots',
                'Yellowing and dropping of leaves'
            ],
            causes: [
                'Wet, humid conditions',
                'Splashing water',
                'Infected seeds or transplants',
                'Poor air circulation'
            ],
            solutions: [
                'Remove and destroy infected leaves',
                'Apply copper fungicide',
                'Use chlorothalonil spray',
                'Improve drainage',
                'Mulch around plants'
            ],
            prevention: [
                'Use certified disease-free seeds',
                'Space plants 24-36 inches apart',
                'Water in morning hours',
                'Avoid working with wet plants'
            ]
        },
        {
            disease: 'Bacterial Spot',
            pest: 'Xanthomonas campestris (bacteria)',
            confidence: 83,
            symptoms: [
                'Small dark brown spots on leaves',
                'Yellow halo around spots',
                'Raised spots on fruits',
                'Leaf drop and defoliation'
            ],
            causes: [
                'Warm, wet weather',
                'Contaminated seeds',
                'Splashing rain or irrigation',
                'Wounds from insects or pruning'
            ],
            solutions: [
                'Apply copper-based bactericide',
                'Remove severely infected plants',
                'Avoid overhead watering',
                'Disinfect tools between plants',
                'Use drip irrigation'
            ],
            prevention: [
                'Use disease-free certified seeds',
                'Rotate crops for 3 years',
                'Avoid working with wet plants',
                'Plant resistant varieties'
            ]
        },
        {
            disease: 'Fusarium Wilt',
            pest: 'Fusarium oxysporum (soil-borne fungus)',
            confidence: 90,
            symptoms: [
                'Yellowing of lower leaves',
                'Wilting on one side of plant',
                'Brown discoloration in stem',
                'Stunted growth and plant death'
            ],
            causes: [
                'Contaminated soil',
                'Warm soil temperatures',
                'Root damage',
                'Acidic soil conditions'
            ],
            solutions: [
                'Remove and destroy infected plants',
                'Solarize soil before replanting',
                'Use resistant varieties',
                'Improve soil drainage',
                'Adjust soil pH to 6.5-7.0'
            ],
            prevention: [
                'Plant resistant varieties',
                'Rotate crops for 4-5 years',
                'Avoid root damage during cultivation',
                'Maintain proper soil pH'
            ]
        },
        {
            disease: 'Verticillium Wilt',
            pest: 'Verticillium dahliae (soil-borne fungus)',
            confidence: 86,
            symptoms: [
                'Yellowing between leaf veins',
                'Wilting during hot days',
                'Brown streaks in stem tissue',
                'Gradual plant decline'
            ],
            causes: [
                'Cool soil temperatures',
                'Contaminated soil',
                'Infected plant debris',
                'Stress conditions'
            ],
            solutions: [
                'Remove infected plants immediately',
                'Solarize soil in summer',
                'Plant resistant varieties',
                'Improve soil health with compost',
                'Avoid planting susceptible crops'
            ],
            prevention: [
                'Use resistant varieties',
                'Rotate with non-susceptible crops',
                'Maintain plant health',
                'Test soil before planting'
            ]
        },
        {
            disease: 'Aphid Infestation',
            pest: 'Various aphid species (insects)',
            confidence: 94,
            symptoms: [
                'Clusters of small soft-bodied insects',
                'Sticky honeydew on leaves',
                'Curled and distorted leaves',
                'Sooty mold growth'
            ],
            causes: [
                'Warm weather',
                'Nitrogen-rich fertilizer',
                'Lack of natural predators',
                'Stressed plants'
            ],
            solutions: [
                'Spray with strong water jet',
                'Apply insecticidal soap',
                'Use neem oil spray',
                'Introduce ladybugs',
                'Apply horticultural oil'
            ],
            prevention: [
                'Encourage beneficial insects',
                'Use reflective mulches',
                'Avoid over-fertilizing',
                'Monitor plants regularly'
            ]
        },
        {
            disease: 'Tomato Hornworm Damage',
            pest: 'Manduca quinquemaculata (caterpillar)',
            confidence: 96,
            symptoms: [
                'Large holes in leaves',
                'Defoliation of entire branches',
                'Dark green droppings on leaves',
                'Visible large green caterpillars'
            ],
            causes: [
                'Adult moths laying eggs',
                'Warm summer weather',
                'Presence of host plants',
                'Lack of natural predators'
            ],
            solutions: [
                'Hand-pick and destroy caterpillars',
                'Apply Bacillus thuringiensis (Bt)',
                'Use spinosad organic insecticide',
                'Encourage parasitic wasps',
                'Till soil in fall to destroy pupae'
            ],
            prevention: [
                'Inspect plants regularly',
                'Encourage beneficial wasps',
                'Use row covers early season',
                'Plant companion plants like marigolds'
            ]
        },
        {
            disease: 'Blossom End Rot',
            pest: 'Calcium deficiency (physiological disorder)',
            confidence: 91,
            symptoms: [
                'Dark, sunken spots on fruit bottom',
                'Leathery texture on affected area',
                'Fruit remains firm elsewhere',
                'Occurs during fruit development'
            ],
            causes: [
                'Calcium deficiency',
                'Inconsistent watering',
                'High nitrogen fertilizer',
                'Rapid plant growth'
            ],
            solutions: [
                'Maintain consistent soil moisture',
                'Apply calcium supplements',
                'Mulch to retain moisture',
                'Avoid over-fertilizing with nitrogen',
                'Water deeply and regularly'
            ],
            prevention: [
                'Test and amend soil pH',
                'Mulch plants well',
                'Water consistently',
                'Avoid excessive nitrogen'
            ]
        },
        {
            disease: 'Leaf Miner Damage',
            pest: 'Liriomyza species (fly larvae)',
            confidence: 89,
            symptoms: [
                'Winding white trails in leaves',
                'Blotchy mines on leaf surface',
                'Reduced photosynthesis',
                'Premature leaf drop'
            ],
            causes: [
                'Adult flies laying eggs in leaves',
                'Warm weather conditions',
                'Lack of natural predators',
                'Continuous cropping'
            ],
            solutions: [
                'Remove and destroy affected leaves',
                'Apply spinosad insecticide',
                'Use neem oil spray',
                'Introduce parasitic wasps',
                'Use yellow sticky traps'
            ],
            prevention: [
                'Use row covers',
                'Encourage beneficial insects',
                'Remove plant debris',
                'Rotate crops annually'
            ]
        },
        {
            disease: 'Spider Mite Infestation',
            pest: 'Tetranychus urticae (arachnid)',
            confidence: 87,
            symptoms: [
                'Fine webbing on leaves',
                'Yellow stippling on leaves',
                'Bronze or brown leaf color',
                'Tiny moving dots on undersides'
            ],
            causes: [
                'Hot, dry conditions',
                'Dusty environment',
                'Lack of natural predators',
                'Stressed plants'
            ],
            solutions: [
                'Spray with strong water jet',
                'Apply insecticidal soap',
                'Use neem oil or horticultural oil',
                'Introduce predatory mites',
                'Increase humidity around plants'
            ],
            prevention: [
                'Maintain adequate moisture',
                'Avoid water stress',
                'Encourage beneficial insects',
                'Keep area free of dust'
            ]
        }
    ];

    return diseases[Math.floor(Math.random() * diseases.length)];
}

// Rule-based chat response
function getRuleBasedResponse(question, context) {
    const q = question.toLowerCase();
    
    if (!context || !context.disease) {
        return "Please analyze a plant image first to get specific recommendations.";
    }
    
    if (q.includes('how often') || q.includes('frequency') || q.includes('when')) {
        return `For ${context.disease}, apply treatment every 7-10 days. Start as soon as symptoms appear and continue for 2-3 weeks after symptoms disappear. Reapply after heavy rain.`;
    }
    
    if (q.includes('organic') || q.includes('natural')) {
        return `Organic treatment options:\n• Neem oil spray (every 7 days)\n• Baking soda solution (1 tbsp per gallon)\n• Copper soap fungicide\n• Bacillus subtilis biological fungicide\n• Milk spray (1:9 milk to water ratio)`;
    }
    
    if (q.includes('product') || q.includes('recommend') || q.includes('buy')) {
        return `Recommended products:\n• Daconil (chlorothalonil) - broad spectrum\n• Bonide Copper Fungicide - organic option\n• Serenade Garden - biological control\n• Mancozeb fungicide - preventive\nAlways follow label instructions!`;
    }
    
    if (q.includes('spread') || q.includes('contagious')) {
        return `${context.disease} spreads through water splash, wind, and contaminated tools. Isolate infected plants, disinfect tools with 10% bleach solution, and avoid working with plants when wet.`;
    }
    
    if (q.includes('save') || q.includes('too late')) {
        return `If less than 50% of the plant is affected, treatment can be effective. Remove all infected parts, apply fungicide, and monitor closely. If more than 50% is damaged, consider removing the plant to prevent spread.`;
    }
    
    return `Based on the detected ${context.disease}, follow the treatment solutions provided. Early detection and consistent treatment are key. Ask me about application frequency, organic options, or product recommendations.`;
}

// AI-powered response using Gemini
async function getAIResponse(message, context) {
    try {
        const geminiApiKey = process.env.GEMINI_API_KEY;
        if (!geminiApiKey) {
            return getRuleBasedResponse(message, context);
        }

        const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${geminiApiKey}`;

        const prompt = `You are a plant disease expert assistant. The user has detected ${context?.disease || 'a plant disease'}. 

User question: ${message}

Provide helpful, concise advice about treatment, prevention, and care. Keep responses under 150 words. Be practical and specific.`;

        const requestBody = {
            contents: [{
                parts: [{ text: prompt }]
            }],
            generationConfig: {
                temperature: 0.7,
                maxOutputTokens: 300
            }
        };

        const response = await axios.post(apiUrl, requestBody, {
            headers: {
                'Content-Type': 'application/json'
            }
        });

        return response.data.candidates[0].content.parts[0].text;
    } catch (error) {
        console.error('Gemini error:', error.message);
        return getRuleBasedResponse(message, context);
    }
}

// Start server
app.listen(PORT, () => {
    console.log(`🌱 Plant Disease Detector server running on http://localhost:${PORT}`);
    console.log(`📡 API endpoints:`);
    console.log(`   - POST /api/analyze - Analyze plant images`);
    console.log(`   - POST /api/questionnaire - Analyze symptom descriptions`);
    console.log(`   - POST /api/chat - Chat with AI assistant`);
    console.log(`\n⚙️  Configuration:`);
    console.log(`   - Gemini API: ${process.env.GEMINI_API_KEY ? '✓ Configured' : '✗ Not configured (using mock data)'}`);
});
